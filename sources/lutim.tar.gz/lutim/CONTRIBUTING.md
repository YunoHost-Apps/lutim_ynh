# Contributing

See how to contribute on the [wiki](https://git.framasoft.org/luc/lutim/wikis/contribute).
